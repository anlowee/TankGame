/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *btn_start;
    QPushButton *btn_readme;
    QPushButton *btn_high;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(662, 488);
        MainWindow->setMinimumSize(QSize(662, 488));
        MainWindow->setStyleSheet(QString::fromUtf8("border-image: url(:/sample/photo/timgD353I83R.jpg);"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        btn_start = new QPushButton(centralWidget);
        btn_start->setObjectName(QString::fromUtf8("btn_start"));
        btn_start->setGeometry(QRect(270, 290, 131, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("Wide Latin"));
        font.setPointSize(11);
        btn_start->setFont(font);
        btn_start->setStyleSheet(QString::fromUtf8("border-image: url(:/sample/photo/startbutton.jpg);"));
        btn_readme = new QPushButton(centralWidget);
        btn_readme->setObjectName(QString::fromUtf8("btn_readme"));
        btn_readme->setGeometry(QRect(270, 330, 132, 21));
        btn_readme->setFont(font);
        btn_readme->setStyleSheet(QString::fromUtf8("border-image: url(:/sample/photo/startbutton.jpg);"));
        btn_high = new QPushButton(centralWidget);
        btn_high->setObjectName(QString::fromUtf8("btn_high"));
        btn_high->setGeometry(QRect(270, 370, 131, 21));
        btn_high->setFont(font);
        btn_high->setStyleSheet(QString::fromUtf8("border-image: url(:/sample/photo/startbutton.jpg);"));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        btn_start->setText(QCoreApplication::translate("MainWindow", "START", nullptr));
        btn_readme->setText(QCoreApplication::translate("MainWindow", "README", nullptr));
        btn_high->setText(QCoreApplication::translate("MainWindow", "HIGH", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
